import json

from rake_nltk import Rake

import spacy

import nltk


def rake_extractor(text):
    r = Rake()
    r.extract_keywords_from_text(text)
    r.get_ranked_phrases()
    list=r.get_ranked_phrases_with_scores()
    # print(list)
    l2=[]
    l=len(r.get_ranked_phrases())
    for i in range(0,l):
        if(r.get_ranked_phrases_with_scores()[i][0]>1):
            # print(r.get_ranked_phrases_with_scores()[i][1])
            l2.append(list[i][1])
            
    if (len(l2)==0 and len(list)>0):
        l2.append(0)
    return(l2)
                
            
            
def lambda_handler(event, context):
    #1. Phrase out query string prams
    text=event['keywords']
    # text='Marqeta card-issuing platform is inspiring new possibilities for the worlds most innovative companies. Learn about our merchant services and virtual card here'

    #2 Construct the body 
    transactionResponse={}
    transactionResponse['keywords']=rake_extractor(text)
    transactionResponse['categories']=word_classifier(text)

    #3 Construct http response object
    responseObject={}
    responseObject['statusCode']=200
    responseObject['headers']={}    
    responseObject['headers']['Content-Type']='application/json'
    responseObject['body']=json.dumps(transactionResponse)

    return responseObject;
    
def word_classifier(text):
    nlp = spacy.load("en_core_web_sm")

    # textf=nlp("By 2020 the telecom company Microsoft will transfer from New Jersey to Orange city. Mr. Hannukah will join his position of General Head from April 2021. Mr. Hannukah is Black")
    textf=nlp(text)
    temp={}
    for word in textf.ents:
        if temp.get(word.label_)!=None:
            temp[word.label_].append(word.text)
        else:
            list=[]
            list.append(word.text)
            temp[word.label_]=list
        
    return temp